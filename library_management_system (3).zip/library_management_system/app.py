from flask import Flask, render_template, request

app = Flask(__name__)

library = []

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/add", methods=["GET", "POST"])
def add():
    if request.method == "POST":
        title = request.form.get("title")
        author = request.form.get("author")
        year = request.form.get("year")
        book = {"title": title, "author": author, "year": year}
        library.append(book)
        return "Book added successfully!"
    return render_template("add.html")

@app.route("/remove", methods=["GET", "POST"])
def remove():
    if request.method == "POST":
        title = request.form.get("title")
        for book in library:
            if book["title"] == title:
                library.remove(book)
                return "Book removed successfully!"
        return "Book not found in library!"
    return render_template("remove.html")

@app.route("/view")
def view():
    return render_template("view.html", library=library)

@app.route("/search", methods=["GET", "POST"])
def search():
    if request.method == "POST":
        search_term = request.form.get("search_term")
        matches = []
        for book in library:
            if search_term in book["title"] or search_term in book["author"] or search_term in book["year"]:
                matches.append(book)
        if matches:
            return render_template("search_results.html", matches=matches)
        return "No matches found in library!"
    return render_template("search.html")

if __name__ == "__main__":
    app.run(debug=True)
